'''
Source code for project solar forcast
'''

import logging
import numpy as np
import utils as utl
import matplotlib.pyplot as plt

from solar_forcast import *
from sklearn import svm
from sklearn.model_selection import KFold
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split

def main(data_path, month_selection, parameters, mode) :

    # read mat data from file
    input_data = utl.read_mat(data_path)

    # data preprocessing
    input_data = utl.data_preprocessing(input_data, month_selection)

    # generate feature vectors
    feats, labels = generate_features(input_data)

    # weather classification
    feats, labels = weather_classification(feats, labels)

    if mode == 'grid search':
        # grid search for each weather

        # sunny day
        # logging.info("Start grid search on sunny days ...")
        # grid_search(feats['sunny'], labels['sunny'], parameters['SUNNY'])
        # logging.info("Grid search on sunny days is complete.")

        # partly cloudy day
        logging.info("Start grid search on partly cloudy days ...")
        grid_search(feats['partly_cloudy'], labels['partly_cloudy'], \
                        parameters['PARTLY CLOUDY'])
        logging.info("Grid search on partly cloudy days is complete.")

        # cloudy day
        logging.info("Start grid search on cloudy days ...")
        grid_search(feats['cloudy'], labels['cloudy'], parameters['CLOUDY'])
        logging.info("Grid search on cloudy days is complete.")

    elif mode == 'holdout training':
        # perform holdout training on each weather

        # sunny day
        logging.info("Start holdout training on sunny days ...")
        holdout_train(feats['sunny'], labels['sunny'], parameters['SUNNY'])
        logging.info("Holdout training on sunny days is complete.")

        # partly cloudy day
        logging.info("Start holdout training on partly cloudy days ...")
        holdout_train(feats['partly_cloudy'], labels['partly_cloudy'], \
                        parameters['PARTLY CLOUDY'])
        logging.info("Holdout training on partly cloudy days is complete.")

        # cloudy day
        logging.info("Start holdout training on cloudy days ...")
        holdout_train(feats['cloudy'], labels['cloudy'], parameters['CLOUDY'])
        logging.info("Holdout training on cloudy days is complete.")

    elif mode == 'weather prediction':

        # get parameters of SVR model under each weather types
        if parameters['SUNNY']['para_path'] is not None :
            sunny_model = utl.restore_model(\
                    parameters['SUNNY']['para_path'])
        else :
            sunny_model = utl.restore_model(\
                    parameters['SUNNY']['name'] + '-grid-search')
        logging.info("Sunny model loaded is {}".format(sunny_model))

        if parameters['CLOUDY']['para_path'] is not None :
            cloudy_model = utl.restore_model(\
                    parameters['CLOUDY']['para_path'])
        else :
            cloudy_model = utl.restore_model(\
                    parameters['CLOUDY']['name'] + '-grid-search')
        logging.info("Cloudy model loaded is {}".format(cloudy_model))

        if parameters['PARTLY CLOUDY']['para_path'] is not None :
            partly_cloudy_model = utl.restore_model(\
                    parameters['PARTLY CLOUDY']['para_path'])
        else :
            partly_cloudy_model = utl.restore_model(\
                    parameters['PARTLY CLOUDY']['name'] + '-grid-search')
        logging.info("Partly cloudy model loaded is {}"\
                    .format(partly_cloudy_model))

        # perform prediction based on weather types

        # sunny day
        logging.info("Start performing predictions on sunny days ...")
        sunny_pred = predict(feats['sunny'], sunny_model)
        logging.info("Weather prediction on sunny days is complete.")

        # partly cloudy day
        logging.info("Start performing predictions on cloudy days ...")
        cloudy_pred = predict(feats['cloudy'], cloudy_model)
        logging.info("Weather prediction on cloudy days is complete.")

        # cloudy day
        logging.info("Start performing predictions on partly cloudy days ...")
        partly_cloudy_pred = predict(feats['partly_cloudy'],partly_cloudy_model)
        logging.info("Weather prediction on partly cloudy days is complete.")

        if labels is not None :
            # computing errors
            sunny_errors = utl.compute_error(sunny_pred, labels['sunny'])
            cloudy_errors = utl.compute_error(cloudy_pred, labels['cloudy'])
            partly_cloudy_errors = utl.compute_error(partly_cloudy_pred,\
                                        labels['partly_cloudy'])

if __name__ == '__main__' :

    # logging set up
    logging.basicConfig(filename='solar_forcast.log', filemode='w',
        level=logging.DEBUG,format='%(asctime)s %(levelname)s %(message)s')

    # path set up
    data_folder = '../data/'
    data_name = 'CESM_for_SVM.mat'
    # path to the optimal model under each weather
    sunny_path = None
    cloudy_path = None
    party_cloudy_path = None

    # consts
    DATA_PATH = data_folder + data_name
    MODE = 'grid search'
    # MODE = 'holdout training'
    # MODE = 'weather prediction'
    MONTH_SELECTION = np.array([1,2,3])
    SUNNY_PARA = {'name': 'sunny', \
                  'test_size' : 0.2, \
                  'kernel' : 'rbf', \
                  'c' : 20, \
                  'epsilon' : 0.1, \
                  'gamma' : 0.2, \
                  'k_for_kfold' : 5, \
                  'c_pool' : [2e-5,2e-4,2e-3,2e-2,\
                      2e-1,2,20,2e2,2e3,2e4,2e5,2e6], \
                  'epsilon_pool' : [0.1], \
                  'gamma_pool' : [2e-5,2e-4,2e-3,2e-2,\
                      2e-1,2,20,2e2,2e3], \
                  'para_path' : sunny_path}

    CLOUDY_PARA = {'name' : 'cloudy', \
                   'test_size' : 0.2, \
                   'kernel' : 'rbf', \
                   'c' : 20, \
                   'epsilon' : 0.1, \
                   'gamma' : 0.2, \
                   'k_for_kfold' : 5, \
                   'c_pool' : [2e-5,2e-4,2e-3,2e-2,\
                       2e-1,2,20,2e2,2e3,2e4,2e5,2e6], \
                   'epsilon_pool' : [0.1], \
                   'gamma_pool' : [2e-5,2e-4,2e-3,2e-2,\
                       2e-1,2,20,2e2,2e3], \
                   'para_path' : cloudy_path}

    PARTLY_CLOUDY_PARA = {'name' : 'partly_cloudy', \
                          'test_size' : 0.2, \
                          'kernel' : 'rbf', \
                          'c' : 20, \
                          'epsilon' : 0.1, \
                          'gamma' : 0.2, \
                          'k_for_kfold' : 5, \
                          'c_pool' : [2e-5,2e-4,2e-3,2e-2,\
                              2e-1,2,20,2e2,2e3,2e4,2e5,2e6], \
                          'epsilon_pool' : [0.1], \
                          'gamma_pool' : [2e-5,2e-4,2e-3,2e-2,\
                              2e-1,2,20,2e2,2e3], \
                          'para_path' : party_cloudy_path}

    PARAMETERS = {'SUNNY' : SUNNY_PARA, \
                  'CLOUDY' : CLOUDY_PARA, \
                  'PARTLY CLOUDY' : PARTLY_CLOUDY_PARA}

    # main()
    main(DATA_PATH, MONTH_SELECTION, PARAMETERS, MODE)


